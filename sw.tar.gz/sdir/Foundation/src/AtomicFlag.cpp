//
// AtomicFlag.cpp
//
// Library: Foundation
// Package: Core
// Module:  AtomicFlag
//
// Copyright (c) 2009, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/AtomicCounter.h"

